def mean(x: list) -> float:
    """ Calculate the mean of a list of numbers.    """
    return sum(x) / len(x)
